package project3;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/websites")
public class web extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	String sites = req.getParameter("site");
    	System.out.println(sites);

        if (sites != null) {
            switch (sites) {
                case "youtube":
                    resp.sendRedirect("https://www.youtube.com");
                    break;
                case "amazonprime":
                    resp.sendRedirect("https://www.primevideo.com/offer");
                    break;
                case "hotstar":
                    resp.sendRedirect("https://www.hotstar.com");
                    break;
                case "netflix":
                    resp.sendRedirect("https://www.netflix.com");
                    break;
                case "sonylive":
                    resp.sendRedirect("https://www.sonyliv.com");
                    break;
            }
        }
        
}
}




package project3;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet(urlPatterns = "/signin")
public class signin extends HttpServlet{
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		String pwd = req.getParameter("pass");
		System.out.println(name);
		System.out.println(email);
		System.out.println(pwd);
		
		Connection con = null;
        PreparedStatement ps = null;

	
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		 con = DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=root");
		 ps = con.prepareStatement("insert into project2.signin values(?,?,?)");
		ps.setString(1, name);
		ps.setString(2, email);
		ps.setString(3, pwd);
		ps.executeUpdate();
		
		 RequestDispatcher rd = req.getRequestDispatcher("login.html");
         rd.forward(req, resp);
			
	} catch (ClassNotFoundException | SQLException e) {
        e.printStackTrace();
    } finally {
      
        try {
            if (ps != null) ps.close();
            if (con != null) con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

	
		
	}

}

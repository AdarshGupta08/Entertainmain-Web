package ServletLifeCycle;

import java.io.IOException;

import javax.servlet.GenericServlet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
@WebServlet(urlPatterns = "/hello",loadOnStartup = 10)
public class hello extends GenericServlet {
	
	public hello() {
		System.out.println("Object is created of hello class");
		
	}
	
	@Override
	public void init() throws ServletException {
		System.out.println("Init method is invoked");
	}

	@Override
	public void service(ServletRequest req, ServletResponse resp) throws ServletException, IOException {
		String  h1 = req.getParameter("h1");
		System.out.println(h1);
		RequestDispatcher rd = req.getRequestDispatcher("by.html");
		rd.forward(req, resp);
		
		
	}
	@Override
	public void destroy() {
		System.out.println("Object is Destroyed");
	}	
	
}
	
